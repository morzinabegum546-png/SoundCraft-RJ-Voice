//! The RJ Voice preset: a one-click, broadcast-radio vocal chain.
//!
//! `mix.rj_voice` fills a track's inserts A-G with a clean, warm, present and loud "radio jockey"
//! voice: rumble and mud removed, the gaps between words gated down, sibilance tamed, the level
//! evened out, chest warmth and air added, a touch of tube-style harmonics and a brickwall
//! finish. Every stage is a built-in SoundCraft plugin, so the result is plain session data: the
//! person can open any insert afterwards and tweak it, and one Undo restores what was there.

use super::{CommandSpec, bad, bool_or, has_tracks, tracks_required};
use crate::{Engine, Result, cmd};
use serde_json::{Value, json};
use soundcraft_model::Insert;

/// The preset name every insert of the chain carries (shown in the plugin window header, and how
/// `off` finds the chain again).
pub const PRESET_NAME: &str = "RJ Voice";

/// One stage of the chain: a built-in plugin id and the parameters that differ from its defaults.
type Stage = (&'static str, &'static [(&'static str, f32)]);

/// The chain in signal order (inserts A-G).
pub const CHAIN: &[Stage] = &[
    // A - Clean-up. Steep high-pass below the voice (mic-stand rumble, AC and mains hum at 50/60 Hz,
    // plosive thumps), a gentle cut in the boxy low mids and a low-pass above the useful top
    // end so tape-style hiss is not carried into the later gain stages.
    (
        "eq_7band",
        &[
            ("hpf_on", 1.0),
            ("hpf_freq", 85.0),
            ("hpf_slope", 3.0),
            ("low_mid_freq", 300.0),
            ("low_mid_gain", -2.5),
            ("low_mid_q", 1.2),
            ("lpf_on", 1.0),
            ("lpf_freq", 15_000.0),
            ("lpf_slope", 1.0),
        ],
    ),
    // B - Noise gate. A soft, wide expander (not a hard gate), so room tone, breath hiss and fan
    // noise fall away between words without chopping word endings.
    ("expander_gate", &[("threshold", -46.0), ("ratio", 4.0), ("range", 28.0), ("attack", 1.5), ("hold", 150.0), ("release", 280.0)]),
    // C - De-esser, before the compressor so the compressor cannot push "s" sounds up.
    ("de_esser", &[("freq", 6500.0), ("range", 8.0), ("threshold", -32.0)]),
    // D - Leveller. Smooth, medium-ratio compression with a sidechain high-pass so the body
    // of the voice, not its low end, drives the gain reduction: the steady, "in your face" radio level.
    (
        "compressor",
        &[
            ("threshold", -22.0),
            ("ratio", 3.5),
            ("attack", 6.0),
            ("release", 90.0),
            ("knee", 8.0),
            ("makeup", 5.0),
            ("sc_hpf_on", 1.0),
            ("sc_hpf_freq", 120.0),
        ],
    ),
    // E - Radio tone. Proximity warmth in the chest, a little mud out, presence for clarity and
    // an "air" shelf on top: the polished, expensive-sounding announcer voice.
    (
        "eq_7band",
        &[
            ("low_shelf_freq", 110.0),
            ("low_shelf_gain", 3.5),
            ("low_mid_freq", 250.0),
            ("low_mid_gain", -1.5),
            ("low_mid_q", 1.0),
            ("high_mid_freq", 4500.0),
            ("high_mid_gain", 2.5),
            ("high_mid_q", 0.9),
            ("high_shelf_freq", 11_000.0),
            ("high_shelf_gain", 2.5),
            ("high_shelf_q", 0.7),
        ],
    ),
    // F - Colour. A subtle, slightly asymmetric tube-style saturation blended in for density.
    ("saturator", &[("drive", 4.0), ("bias", 12.0), ("tone", 14_000.0), ("mix", 35.0), ("output", -1.0)]),
    // G - Finish. A brickwall maximizer for broadcast loudness that never clips.
    ("maximizer", &[("threshold", -4.0), ("ceiling", -1.0), ("release", 60.0)]),
];

pub fn specs() -> Vec<CommandSpec> {
    vec![cmd!(
        "mix.rj_voice",
        "RJ Voice (Radio Preset)",
        [],
        None,
        "{tracks?, off?: false} — builds a broadcast-radio voice (clean-up EQ, noise gate, de-esser, compressor, radio tone EQ, saturation, maximizer) in inserts A-G; \
         whatever was in A-G is replaced (Undo restores it), H-J are left alone. `off: true` removes the chain again",
        has_tracks,
        rj_voice
    )]
}

/// One stage as an insert: every parameter at its default, then the stage's own values (clamped
/// into range) and the preset name.
fn stage_insert(plugin: &str, params: &[(&str, f32)]) -> Result<Insert> {
    let info = soundcraft_dsp::plugin_info(plugin).ok_or_else(|| bad("mix.rj_voice", format!("unknown plugin `{plugin}`")))?;
    let mut ins = Insert::new(info.id);
    for pi in info.params {
        ins.params.insert(pi.id.to_string(), pi.default);
    }
    for &(key, value) in params {
        let pi = info.param(key).ok_or_else(|| bad("mix.rj_voice", format!("`{plugin}` has no parameter `{key}`")))?;
        ins.params.insert(key.to_string(), pi.clamp(value));
    }
    ins.preset = PRESET_NAME.to_string();
    Ok(ins)
}

/// The whole chain as inserts, in order.
fn build_chain() -> Result<Vec<Insert>> {
    CHAIN.iter().map(|(plugin, params)| stage_insert(plugin, params)).collect()
}

fn rj_voice(e: &mut Engine, p: &Value) -> Result<Value> {
    let tracks = tracks_required(e, "mix.rj_voice", p)?;
    let off = bool_or(p, "off", false);
    // Built before the session is touched, so a mistake in the table can never half-apply.
    let chain = if off { Vec::new() } else { build_chain()? };
    let s = e.session_mut();
    let mut done = Vec::new();
    for t in tracks {
        let Some(tr) = s.track_mut(t) else { continue };
        if off {
            for slot in tr.mixer.inserts.iter_mut() {
                if slot.as_ref().is_some_and(|i| i.preset == PRESET_NAME) {
                    *slot = None;
                }
            }
        } else {
            for (slot, ins) in tr.mixer.inserts.iter_mut().zip(chain.iter()) {
                *slot = Some(ins.clone());
            }
        }
        done.push(t);
    }
    Ok(json!({"tracks": done, "stages": if off { 0 } else { chain.len() }}))
}

#[cfg(test)]
mod tests {
    use super::*;
    use soundcraft_model::{ChannelFormat, Session, TrackId, TrackKind};

    fn voice_track() -> (Engine, TrackId) {
        let mut s = Session::default();
        let t = s.add_track(TrackKind::Audio, ChannelFormat::Mono, Some("Voice"));
        (Engine::new(s), t)
    }

    #[test]
    fn every_stage_names_real_plugins_and_parameters() {
        let chain = build_chain().unwrap();
        assert_eq!(chain.len(), CHAIN.len());
        for (ins, (plugin, params)) in chain.iter().zip(CHAIN) {
            assert_eq!(ins.plugin, *plugin);
            let info = soundcraft_dsp::plugin_info(plugin).unwrap();
            for (key, value) in *params {
                let pi = info.param(key).unwrap();
                assert!(
                    (pi.min..=pi.max).contains(value),
                    "{plugin}.{key} = {value} is outside {}..{} and would be clamped",
                    pi.min,
                    pi.max
                );
            }
        }
    }

    #[test]
    fn rj_voice_fills_a_to_g_with_the_chain() {
        let (mut e, t) = voice_track();
        e.execute("mix.rj_voice", &json!({"track": t.0})).unwrap();
        let inserts = &e.session().track(t).unwrap().mixer.inserts;
        for (slot, (plugin, params)) in CHAIN.iter().enumerate() {
            let ins = inserts[slot].as_ref().unwrap();
            assert_eq!(ins.plugin, *plugin);
            assert_eq!(ins.preset, PRESET_NAME);
            assert!(!ins.bypass);
            for (key, value) in *params {
                assert!((ins.params[*key] - value).abs() < 1e-4, "{plugin}.{key}");
            }
        }
        assert!(inserts[CHAIN.len()..].iter().all(Option::is_none));
    }

    #[test]
    fn rj_voice_replaces_a_to_g_but_keeps_h_to_j_and_is_undoable() {
        let (mut e, t) = voice_track();
        e.execute("mix.insert", &json!({"track": t.0, "slot": 0, "plugin": "gain"})).unwrap();
        e.execute("mix.insert", &json!({"track": t.0, "slot": 8, "plugin": "chorus"})).unwrap();
        e.execute("mix.rj_voice", &json!({"track": t.0})).unwrap();
        let inserts = e.session().track(t).unwrap().mixer.inserts.clone();
        assert_eq!(inserts[0].as_ref().unwrap().plugin, "eq_7band");
        assert_eq!(inserts[8].as_ref().unwrap().plugin, "chorus");
        e.execute("edit.undo", &json!({})).unwrap();
        let inserts = &e.session().track(t).unwrap().mixer.inserts;
        assert_eq!(inserts[0].as_ref().unwrap().plugin, "gain");
        assert!(inserts[1].is_none());
    }

    #[test]
    fn applying_twice_gives_the_same_chain_and_off_removes_only_it() {
        let (mut e, t) = voice_track();
        e.execute("mix.insert", &json!({"track": t.0, "slot": 9, "plugin": "chorus"})).unwrap();
        e.execute("mix.rj_voice", &json!({"track": t.0})).unwrap();
        let first = e.session().track(t).unwrap().mixer.inserts.clone();
        e.execute("mix.rj_voice", &json!({"track": t.0})).unwrap();
        assert_eq!(e.session().track(t).unwrap().mixer.inserts, first);
        e.execute("mix.rj_voice", &json!({"track": t.0, "off": true})).unwrap();
        let inserts = &e.session().track(t).unwrap().mixer.inserts;
        assert!(inserts[..CHAIN.len()].iter().all(Option::is_none));
        assert_eq!(inserts[9].as_ref().unwrap().plugin, "chorus");
    }

    #[test]
    fn rj_voice_needs_a_track() {
        let mut e = Engine::new(Session::default());
        assert!(e.execute("mix.rj_voice", &json!({})).is_err());
    }
}
