# RJ Voice preset

One click turns a voice track into a clean, warm, polished broadcast-radio ("RJ") voice.

**Where:** Mixer → click (or right-click) any insert slot → **RJ Voice (Radio Preset)**.
Also available everywhere commands run: command palette, CLI, control channel and MCP as `mix.rj_voice`.

```
soundcraft-cli run --cmd 'mix.rj_voice={"track":"Voice"}' --bounce voice_rj.wav
```

Params: `{tracks?, off?: false}`. It fills inserts A-G (whatever was there is replaced; Undo
restores it) and leaves H-J alone. `off: true` removes the chain again.

| Slot | Plugin | Job |
|---|---|---|
| A | EQ 7-Band | 85 Hz 24 dB/oct high-pass (rumble, mains hum, plosives), -2.5 dB at 300 Hz (boxiness), 15 kHz low-pass (hiss) |
| B | Expander/Gate | soft 4:1 expander, 28 dB range, 150 ms hold: silences room/fan noise between words without chopping |
| C | De-Esser | 6.5 kHz, up to 8 dB |
| D | Compressor/Limiter | 3.5:1, 6 ms attack, 90 ms release, sidechain HPF 120 Hz, +5 dB makeup: steady radio level |
| E | EQ 7-Band | +3.5 dB chest warmth at 110 Hz, -1.5 dB at 250 Hz, +2.5 dB presence at 4.5 kHz, +2.5 dB air shelf at 11 kHz |
| F | Saturator | 35 % blend of gentle asymmetric tube-style saturation |
| G | Maximizer | -1 dB ceiling, broadcast loudness without clipping |

The chain is defined in `crates/engine/src/cmd/rj_voice.rs` (`CHAIN`). Every stage is an ordinary
insert, so each one can be opened and tuned. The gate threshold (-46 dB) suits a normal close-mic
recording; raise it for noisier rooms, lower it for very quiet ones.
